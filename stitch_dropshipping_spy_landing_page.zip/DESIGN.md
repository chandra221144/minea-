---
name: Kinetic Growth Engine
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daef'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e9edff'
  surface-container-high: '#e1e8fd'
  surface-container-highest: '#dce2f7'
  on-surface: '#141b2b'
  on-surface-variant: '#5b403b'
  inverse-surface: '#293040'
  inverse-on-surface: '#edf0ff'
  outline: '#8f7069'
  outline-variant: '#e4beb6'
  surface-tint: '#b72202'
  primary: '#b41f00'
  on-primary: '#ffffff'
  primary-container: '#d73a1a'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb4a4'
  secondary: '#0a6d3a'
  on-secondary: '#ffffff'
  secondary-container: '#9ef6b6'
  on-secondary-container: '#167340'
  tertiary: '#7b5500'
  on-tertiary: '#ffffff'
  tertiary-container: '#9b6b00'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad3'
  primary-fixed-dim: '#ffb4a4'
  on-primary-fixed: '#3e0500'
  on-primary-fixed-variant: '#8d1600'
  secondary-fixed: '#9ef6b6'
  secondary-fixed-dim: '#83d99b'
  on-secondary-fixed: '#00210d'
  on-secondary-fixed-variant: '#00522a'
  tertiary-fixed: '#ffdeac'
  tertiary-fixed-dim: '#ffba38'
  on-tertiary-fixed: '#281900'
  on-tertiary-fixed-variant: '#604100'
  background: '#f9f9ff'
  on-background: '#141b2b'
  surface-variant: '#dce2f7'
  surface-ivory: '#F9EBD7'
  surface-ivory-soft: '#FDF7EF'
  surface-white: '#FFFFFF'
  text-muted: '#64748B'
  border-subtle: '#E7D8C4'
  border-light: '#E2E8F0'
  emerald-tint: '#E8F5EE'
typography:
  display-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 38px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
  space-3xl: 6rem
---

## Brand & Style

This design system is engineered for modern high-performance SaaS affiliate and e-commerce analytics funnels. Drawing visual energy from high-velocity product intelligence tools and contemporary direct-to-consumer software, it balances rigorous algorithmic authority with visceral conversion momentum.

The design philosophy combines **Modern Functional SaaS** with **Tactile High-Conversion Polish**:
- **Target Audience:** Digital entrepreneurs, dropshippers, growth marketers, and performance affiliate operators who demand instant data clarity, proof-led validation, and low cognitive friction.
- **Atmosphere & Tone:** Authoritative yet dynamic, trustworthy, and urgency-conscious without feeling cheap or spammy.
- **Visual Aesthetic:** Architectural container surfaces, warm organic background planes, crisp hairline borders, saturated conversion anchors, and high-density metric callouts. Micro-interactions communicate immediacy through snappy responsiveness and physical pill-shaped feedback indicators.

## Colors

The palette leverages high-contrast tension between deep organic stability, warm textural warmth, and electrifying conversion triggers:

- **Primary Action (Vermilion - `#E34222`):** Reserved strictly for focal intent: primary hero CTAs, checkout triggers, flash badges, and conversion links. It commands immediate optical priority.
- **Secondary Anchor (Emerald Green - `#046A38`):** Represents algorithmic accuracy, validated revenue, profit metrics, live tracking pings, and verification chips. Paired with `emerald-tint` (`#E8F5EE`) for badge fills.
- **Tertiary Accent (Amber - `#FFB728`):** Used sparingly for 5-star social proof ratings, highlight badges, and live alert indicators.
- **Foundation & Surfaces (Warm Ivory - `#F9EBD7` & `#FDF7EF`):** Replaces clinical stark white with organic, high-end editorial warmth. Pure `#FFFFFF` cards float cleanly above this ivory substrate.
- **Typography & Structure (`#111827` & `#64748B`):** Deep slate neutrals deliver maximum legibility and structural discipline across metric cards and headers.

## Typography

The typographic hierarchy bridges the modern kinetic energy of **Plus Jakarta Sans** for expressive, conversion-driven display titles and the rock-solid utilitarian density of **Inter** for dense data tables, product specs, and UI mechanics.

- **Headlines & Value Propositions:** Rendered in tight-tracked, heavy-weight Plus Jakarta Sans to project confidence, scale, and clarity at a glance.
- **Body & Explanatory Copy:** Rendered in Inter with generous line-height to ensure fast scanning of feature breakdowns, testimonials, and FAQ tiers.
- **Numbers & Data Counters:** Digits use tabular figures (`font-variant-numeric: tabular-nums`) to maintain alignment across dynamic revenue cards and live counters.

## Layout & Spacing

The layout model utilizes a standard 12-column responsive fluid grid pinned to a maximum container width of `1240px` for optimal eye scanning:

- **Desktop (>= 1024px):** 12 columns with `1.5rem` gutters and `2rem` outer canvas padding. Section separators adhere to alternating vertical rhythm intervals (`space-2xl` for grouped modules, `space-3xl` between distinct value pillars).
- **Tablet (768px – 1023px):** 8 columns with unified `1.25rem` gutters and adaptive card stacks.
- **Mobile (< 768px):** 4 columns with `1rem` gutters and `1.25rem` outer canvas margin. Multi-column metric dashboards collapse into horizontal swipe carousels or single-column stacked modules with full-width action buttons.
- **Rhythm & Alignment:** Grid cards maintain equal internal padding (`space-lg` desktop, `space-md` mobile) ensuring strict edge-to-edge structural alignment.

## Elevation & Depth

Visual depth is achieved through **crisp multi-layered surface planes** and **micro-tinted ambient shadows**, avoiding heavy muddy drops:

- **Base Layer (L0):** Warm Ivory canvas (`#F9EBD7`) anchors the overall experience.
- **Sub-surface Layer (L1):** Soft Ivory inset modules (`#FDF7EF`) with a hairline border (`1px solid #E7D8C4`) create dedicated zones for feature comparisons.
- **Elevated Interactive Cards (L2):** Pure white surfaces (`#FFFFFF`) floating with a dual-stage shadow: `0 1px 3px rgba(17, 24, 39, 0.04), 0 8px 24px -4px rgba(17, 24, 39, 0.06)` combined with a crisp border (`1px solid #E7D8C4`).
- **Floating Conversion Anchors (L3):** Sticky navigation headers, coupon modals, and persistent bottom conversion bars carry a defined directional elevation: `0 12px 36px -6px rgba(17, 24, 39, 0.12)` alongside an ultra-subtle border stroke.
- **Button Tactility:** Primary vermilion buttons implement a slight down-pressed tactile offset (`active: translateY(1px)`) to mimic high-performance kinetic interfaces.

## Shapes

The geometric architecture pairs balanced, modern card corners with distinctive pill-shaped interactive anchors:

- **Structural Containers & Feature Cards:** Employ standard roundedness (`0.5rem` base, `1rem` on desktop cards), communicating stability and dashboard professionalism.
- **Interactive Triggers & Micro-Badges:** Primary CTAs, discount tag counters, live activity indicators, and category tabs use full-radius pill silhouettes (`9999px`), giving them a friendly, tactile, and highly clickable silhouette.
- **Input Fields & Form Selectors:** Match the base roundedness (`0.5rem`) to remain solid and structural against the rounded cards.

## Components

### Buttons
- **Primary CTA:** Background `#E34222`, text `#FFFFFF`, full pill radius (`9999px`), weight `700`. Subtle shadow: `0 4px 14px 0 rgba(227, 66, 34, 0.35)`. Hover transition elevates saturation and translates up 1px.
- **Secondary / Trust Action:** Background `#046A38`, text `#FFFFFF`, full pill radius, ideal for "Claim Verified Deal" or "Inspect Store Data" actions.
- **Ghost / Outlined:** Border `1.5px solid #111827`, text `#111827`, transparent background. Hover fills with `#FDF7EF`.

### Badges & Pill Tags
- **Trust & Verification Badges:** Background `emerald-tint` (`#E8F5EE`), text `#046A38`, border `1px solid rgba(4, 106, 56, 0.2)`. Features a pulsing 6px green circular status indicator.
- **Discount & Urgency Badges:** Background `#E34222`, text `#FFFFFF`, uppercase tracking (`label-sm`).
- **Category Chips:** Pure white background, `border: 1px solid #E7D8C4`, text `#111827`, hover elevates with subtle shadow.

### Cards & Dashboards
- **Winning Product / Feature Card:** Pure `#FFFFFF` surface with `1px solid #E7D8C4` boundary. Top media viewport with rounded inner corners, followed by structured rows: metric label, green profit indicator, and a full-width vermilion CTA footer.
- **Testimonial & Social Proof Card:** `#FFFFFF` fill, 5-star tertiary gold rating (`#FFB728`), reviewer avatar with a verified purchaser badge (`#046A38`), set inside soft-padded boundaries.

### Inputs & Forms
- **Lead Capture Fields:** White background, `1.5px solid #E7D8C4` border, `0.5rem` radius, `1rem` horizontal padding. Focus state invokes an active ring: `2px solid #E34222` with zero offset.
- **Affiliate Coupon Copy Field:** Inset segmented pill bar containing the coupon string in bold tabular text and a one-click "Copy Code" vermilion pill button nested directly within the container.

### Checkboxes & Radios
- **Checkbox:** `18px x 18px`, `0.25rem` radius. Inactive: border `1.5px solid #64748B`. Active state: background `#046A38` with an embedded white SVG checkmark.